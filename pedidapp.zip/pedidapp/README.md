PedidApp
=======

App de exemplo do livro de Cordova da Casa do Código usando Ionic 1.x.